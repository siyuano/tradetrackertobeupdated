import json
import math
import random
import time
import datetime

from flask import Flask, render_template


import gevent
from gevent.pywsgi import WSGIServer



from socketio import socketio_manage
from socketio.server import SocketIOServer
from socketio.namespace import BaseNamespace
from socketio.mixins import BroadcastMixin



app = Flask(__name__)
app.debug = True

# -----------------------------------------------------------------------
class SocketIOApp(object):
    """Stream sine values"""
    def __call__(self, environ, start_response):
        if environ['PATH_INFO'].startswith('/socket.io'):
            socketio_manage(environ, {'': fakefill_Namespace});


class fakefill_Namespace(BaseNamespace, BroadcastMixin):
    
    def on_sine(self, msg):
        while True:
            x = time.time()
            y = 2.5 * (1 + math.sin(x))
            self.broadcast_event('message', json.dumps(dict(x=x, y=y)))
            gevent.sleep(0.1)

    def on_giveMeFill(self, msg):
        
        counter = 0
        
        while  True:
            counter      = counter+1   
            exchange_list   = ['AMEX', 'BOX', 'CBOE', 'CBCX','ISE','ISCX','MIAX',
                               'ARCA', 'PCST', 'NSDQ', 'BXOX', 'C2', 'PHLX','BATO']

            modelname_list  = ['model_xxx', 'model_yyy', 'model_zzz']
            buy_sell        = ['B', 'S']
            
            fake_model_name = random.choice(modelname_list)
            fake_symbol     = 'fake_symbol'
            fake_exchange   = random.choice(exchange_list)
            fake_buySell    = random.choice(buy_sell)
            fake_qty        = random.randint(1,100)
            fake_account    = 'fake_account'
            fake_transfer   = bool(random.getrandbits(1))
            fake_url        = 'www.google.com'
            fake_review     = ''

            now = datetime.datetime.now().strftime("%H:%M:%S")
            
            # self.broadcast_event('takeTheFill',
            self.emit('takeTheFill', 
                json.dumps(dict(timetick    = now,
                                fillID      = counter,
                                model_name  = fake_model_name, 
                                symbol      = fake_symbol,
                                exchange    = fake_exchange,
                                buySell     = fake_buySell,
                                qty         = fake_qty,
                                account     = fake_account,
                                transfer    = fake_transfer,
                                url         = fake_url,
                                review      = fake_review)))
                                
            gevent.sleep(0.3*random.random())

    def on_giveMeFb(self, msg):
        feedback_list = ['Good', 'Bad']

        while True:
            ID       = random.randint(1, 200)
            feedback = random.choice(feedback_list)

            self.broadcast_event('takeTheFb', json.dumps(dict(ID=ID, feedback=feedback)))
            gevent.sleep(1*random.random()) 

# -------------------------------------------------------------------------
@app.route("/sine")
def beta():
    return render_template("index.html")

@app.route("/")
def home():
    return render_template("fill.html")

def main():
    # http webserver
    http_server = WSGIServer(('', 8000), app)

    # fake fill socket server
    sio_server = SocketIOServer(
        ('', 9999), SocketIOApp(),
        namespace="socket.io",
        policy_server=False
    )

    gevent.joinall([
        gevent.spawn(http_server.serve_forever),
        gevent.spawn(sio_server.serve_forever),
    ])

# ----------------------------------------------------------------------
if __name__ == "__main__":
    main()
