function element_in_scroll(elem) {
	var docViewTop 		= $(window).scrollTop();
	var docViewBottom 	= $(window).height() + docViewTop;

	var elemTop 	= $(elem).offset().top;
	var elemBottom  = $(elem).height() + elemTop;

	return (elemBottom <= docViewBottom) && (elemTop >= docViewTop);
}

$(document).scroll(function(e) {
	if(element_in_scroll("#placeholder > tbody tr:last")) {
		if(tail>=0)
			wow();
	}
});