/*
 * initial log state
 */
var fill_history = [];
var tail = -1;
var window_size = 20;
/*
 * internal state : used to filter the fills displayed.
 */
var internal_buySell  = "";
var internal_Exchange = "";


/* 
 * Change the internal states
 */
function filter_buySell_js() {
    internal_buySell = $("#filter_buySell").val();
    tail = fill_history.length-1;
    updateHistory();
}

function filter_Exchange_js() {
    internal_Exchange = $("#filter_ex").val();
    tail = fill_history.length-1;
    updateHistory();
}

/*
 * transform the json-formatted fill into html format
 */
function private_toTableForm(newFill) {
    thiscolor    = newFill.buySell  == "B" ? "green" : "red";
    thisbackcolor= (newFill.review=="Good" || newFill.review=="Bad") ? "lightgrey" : "white";

    newFill_inTableForm = '<tr id=\"'+newFill.fillID +'\" style=\"color:'+thiscolor+';background-color:'+thisbackcolor +'\">'
                                 + '<td>' + newFill.timetick    + '</td>'
                                 + '<td>' + newFill.fillID      + '</td>'
                                 + '<td>' + newFill.model_name  + '</td>'
                                 + '<td>' + newFill.symbol      + '</td>'
                                 + '<td>' + newFill.exchange    + '</td>'
                                 + '<td>' + newFill.buySell     + '</td>'
                                 + '<td>' + newFill.qty         + '</td>'
                                 + '<td>' + newFill.account     + '</td>'
                                 + '<td>' + newFill.transfer    + '</td>'
                                 + '<td>' + '<a href=\"'+newFill.url + '\" target=\"_blank\">FILL</a></td>'  
                                 + '<td>' + newFill.review    + '</td>'
                                 + '</tr>';

    return newFill_inTableForm;
}

/*
 * functions related to sound effect! It's interesting :)
 */ 
function reviewGood() {
    
    myAudio = document.getElementById("reviewGood");
    myAudio.addEventListener('ended', function() {
        myAudio.load();
    }, false);
    myAudio.play();
}


function reviewBad() {
    myAudio = document.getElementById("reviewBad");
    myAudio.addEventListener('ended', function() {
        myAudio.load();
    }, false);
    myAudio.play();
}

/*
 *   Need to be updated. This version is stupid...

 *   Now we only need to display lasted 20 records in default.
 *   Unless scroll down to the bottom.
 */

function updateHistory() {

    $('#placeholder > tbody').html("");
   
    wow();
}

function wow() {
    var stopPoint = (tail<window_size) ? 0 : (tail-window_size+1);

    for(var i=tail; i>=stopPoint; i--) {    
        var d = fill_history[i];
            
        if(internal_buySell=="" ||  d.buySell == internal_buySell) 
            if(internal_Exchange=="" || d.exchange == internal_Exchange) 
                $('#placeholder > tbody').append(private_toTableForm(d));
    }

    tail = stopPoint-1;
}





