$(function() { 

	var socket = io.connect("id1", {'host': 'localhost', 'port': 9999});

    socket.on('connect', function() {
        socket.emit('giveMeFill', '');
    });

    socket.on('error', function() {
    });
    
    socket.on('disconnect', function() {
    });

    socket.on('takeTheFill', function(msg) { 

        var d = $.parseJSON(msg);
        // (1) store it anyway...(in front)
        fill_history.push(d);
        
        // (2) filter
        condition_1 = (internal_buySell=="" || d.buySell==internal_buySell);
        condition_2 = (internal_Exchange=="" || d.exchange == internal_Exchange);
        if( condition_1 && condition_2){
            $('#placeholder > tbody').prepend(private_toTableForm(d));
        }    
    }); 
});