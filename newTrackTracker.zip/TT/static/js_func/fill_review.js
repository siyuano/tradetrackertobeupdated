$(function() { 

    var socket  = io.connect("id2", {'host': 'localhost', 'port': 9999});

    socket.on('connect', function() {
        socket.emit('giveMeFb', '');
    });

    socket.on('error', function() {
    });
    
    socket.on('disconnect', function() {
    });

    socket.on('takeTheFb', function(msg) { 
        
        var fb = $.parseJSON(msg);
        
        $("#ave").html(fb.ID + ' : ' + fb.feedback);
        
        // check if this feedback is valid
        if(fb.ID < fill_history.length) {

            // (1) update history
            d = fill_history[fb.ID-1];
            d.review = fb.feedback;

            // (2) update the table
            //     go through all the filters to be displayed
            if(internal_buySell=="" || d.buySell==internal_buySell) {
                if(internal_Exchange=="" || d.exchange == internal_Exchange) {
                    $('#' + fb.ID + ' td:nth-child(11)').html(fb.feedback);
                    $('#' + fb.ID).css("background-color", "lightgrey");
                  
                    // ...
                    if(fb.feedback=="Good")
                        reviewGood();
                    else
                        reviewBad();
                    // ...
                }
            }
        }
    });
});