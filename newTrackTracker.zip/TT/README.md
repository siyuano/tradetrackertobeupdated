gevent-socketio-example
========================

Mini app using gevent and socketio


To Install and Run
------------------

    python setup.py install
    python app.py

Then point a browser at http://localhost:8000


Credits / Resources
-------------------

http://blog.pythonisito.com/2011/08/websockets-to-socketio.html

https://github.com/abourget/gevent-socketio/tree/master/examples
